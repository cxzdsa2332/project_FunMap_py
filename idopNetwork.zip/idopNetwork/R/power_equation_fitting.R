#' @title remove observation with too many 0 values
#' @param data dataframe of imported dataset, must have first column as ID
#' @param x scales indicate how many 0 to remove
#' @return a dataframe without too many 0 observations
#' @examples
#' data_cleaning(matrix(c(c(0,1,1,0,0,1,1), c(2,1,0,3,5,2,2), c(1,1,3,2,4,5,1)), 3, 7), 2)
#' @importFrom stats aggregate
#' @export
data_cleaning <- function(data, x = round(ncol(data)*0.3)){
  f <- function(x) length(which((as.numeric(x)==0)))
  data = aggregate(data[,2:ncol(data)], by=list(data[,1]), FUN = 'sum')
  rownames(data) = data[,1]
  data = data[,-1]
  rm_no = c(which(as.numeric(apply(data, 1, f))>=x))
  data = data[-rm_no,]
  return(data)
}


#' @title use power equation parameters to generate y values
#' @param x vector for x values
#' @param power_par matrix contain parameters for power equation
#' @return y values for given power equation parameters
#' @examples
#' power_equation(c(1,2,3,5,7), matrix(c(2,1,1,2),2,2))
#' @export
power_equation <- function(x, power_par){ t(sapply(1:nrow(power_par),
                                                   function(c) power_par[c,1]*x^power_par[c,2] ) )}


#' @title use power equation to fit observed values
#' @param x vector for x values
#' @param y vector for y valyes
#' @return nls model
#' @examples
#' power_equation_base(c(1,2,3,5,7), c(5,10,15,17,20))
#' @importFrom stats nls nls.control runif
#' @export
power_equation_base <- function(x, y){
  x <- as.numeric(x)
  y <- as.numeric(y)
  model <- try(nls(y~a*x^b,start = list(a = runif(1,min = -1, max = 1),
                                        b = runif(1,min = -1, max = 1)),
                   control = nls.control(maxiter = 1e4, minFactor = 1e-200)))
  if( 'try-error' %in% class(model)) {
    result = NULL
  }
  else{
    result = model
  }
  return(result)
}


#' @title use power equation to fit observed values
#' @param x vector for x values
#' @param y vector for y values
#' @param maxit numeric value for maximum initial pars try
#' @return nls model
#' @examples
#' power_equation_all(c(1,2,3,5,7), c(5,10,15,17,20))
#' @export
power_equation_all <- function(x,y, maxit=1e3){
  result <- power_equation_base(x,y)
  iter <- 1
  while( is.null(result) && iter <= maxit) {
    iter <- iter + 1
    try(result <- power_equation_base(x,y))
  }
  return(result)
}

#' @title use power equation to fit given dataset
#' @param data cleaned dataframe
#' @param n scales for how many interpolation needed
#' @param trans indicate log/log2/log10 transform dataset
#' @return list contain power equation parameters and fitted data
#' @examples
#' power_equation_fit(matrix(rnorm(100)+1,10,10))
#' @importFrom stats coef predict
#' @export
power_equation_fit <- function(data, n=30, trans = log10) {
  X = trans(colSums(data+1))
  trans_data = trans(data+1)
  colnames(trans_data) = X

  core.number <- detectCores()
  cl <- makeCluster(getOption("cl.cores", core.number))
  clusterExport(cl, c("power_equation_all", "power_equation_base"))
  all_model = parLapply(cl = cl, 1:nrow(data), function(c) power_equation_all(X, trans(data[c,]+1)))
  stopCluster(cl)

  names(all_model) = rownames(data)
  new_x = seq(min(X), max(X), length = n)
  power_par = t(vapply(all_model, coef, FUN.VALUE = numeric(2), USE.NAMES = TRUE))
  power_fit = t(vapply(all_model, predict, newdata = data.frame(x=new_x),
                       FUN.VALUE = numeric(n), USE.NAMES = TRUE))

  colnames(power_fit) = new_x
  result = list(original_data = data, trans_data = trans_data, power_par = power_par, power_fit = power_fit)
  return(result)
}


#' @title plot power equation fitting results
#' @import ggplot2 scales
#' @importFrom reshape2 melt
#' @param result list object returned from power_equation_fit
#' @param label relabel x and y label due to log-transform, set 10 as default
#' @param n scales for how many subplots needed
#' @return plot show power curve fitting result
#' @export
power_equation_plot <- function(result, label = math_format(expr = 10^.x), n = 9){
  data1 = result[[1]]
  data2 = result[[3]]

  no = sample(1:nrow(data1),n)

  df_original =  reshape2::melt(as.matrix(data1[no,]))
  df_fit = reshape2::melt(as.matrix(data2[no,]))

  p <- ggplot() +
    geom_point(df_original, mapping = aes(x = Var2, y = value,colour = Var1),
               size = 1.25, show.legend = F, alpha = 0.85) +
    geom_line(df_fit, mapping = aes(x = Var2, y = value,colour = Var1), size = 1.15, show.legend = F)  +
    facet_wrap(~Var1) +
    xlab("Habitat Index") + ylab("Niche Index") + theme(axis.title=element_text(size=18)) +
    scale_x_continuous(labels = label) + scale_y_continuous(labels = label) +
    geom_text(df_fit, mapping = aes(label = Var1), show.legend = FALSE,
              x = mean(df_fit$Var2), y = max(df_original$Var2)*0.8, check_overlap = TRUE, size = 4) +
    theme_bw() +
    theme(axis.title=element_text(size=15),
          axis.text.x = element_text(size=10),
          axis.text.y = element_text(size=10,hjust = 0),
          panel.spacing = unit(0.0, "lines"),
          plot.margin = unit(c(1,1,1,1), "lines"),
          strip.background = element_blank(),
          plot.background = element_blank(),
          strip.text = element_blank())
  return(p)
}


