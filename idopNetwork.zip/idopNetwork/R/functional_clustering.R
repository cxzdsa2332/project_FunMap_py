#' @title Q-function to replace log-likelihood function
#' @importFrom mvtnorm dmvnorm
#' @param par numeric vector for parameters need to be estimated
#' @param prob_log mixture component weights(log)
#' @param omega_log latent variables(log)
#' @param X matrix for cluster
#' @param k vector for the cluster number
#' @param times vector for the x values or time points
#' @importFrom mvtnorm dmvnorm
#' @return the Loglikelihood value
Q_function <- function(par, prob_log, omega_log, X, k, times){
  n = dim(X)[1]; d = dim(X)[2];
  X = log2(X+1)

  par.cov <- par[1:2]
  par.mu <- matrix(par[-c(1:2)],nrow = k,ncol = 2 )

  cov = get_SAD1_covmatrix(par.cov[1:2], n = d)

  mu <- power_equation(times, par.mu[1:k,1:2])

  mvn.log <- sapply(1:k, function(c) dmvnorm(X, mu[c,], cov, log = T))

  tmp = sweep(mvn.log, 2, FUN = "+", STATS = prob_log) - omega_log
  Q = -sum(tmp*exp(omega_log))
  return(Q)
}

#' @title acquire initial parameters for functional clustering
#' @importFrom stats kmeans
#' @param X matrix for cluster
#' @param k vector for the cluster number
#' @param times vector for the x values or time points
#' @return the initial parameters for functional clustering
#' @export
get_par_int <- function(X, k, times){
  n = dim(X)[1]; d = dim(X)[2];
  cov.int = c(0.8,0.5)

  init.cluster <- kmeans(X,centers = k)
  prob <- table(init.cluster$cluster)/n

  fit <- lapply(1:k,function(c) power_equation_all(times,init.cluster$centers[c,]))
  mu.par.int <- t(sapply(fit, coef))

  return_obj <- list(initial_cov_params = cov.int,
                     initial_mu_params = mu.par.int,
                     initial_probibality = prob)
  return(return_obj)
}


#' @title main function for functional clustering
#' @param data matrix or data for cluster
#' @param k vector for the cluster number
#' @param trans indicate log/log2/log10 transform dataset
#' @param inv.cov matrix for directly solve cov matrix, default not given(currently not available)
#' @param initial.pars vector for manual give initial parameters, default not given
#' @param iter.max scales control iteration for EM algorithm
#' @importFrom mvtnorm dmvnorm
#' @importFrom stats optim
#' @return the initial parameters for functional clustering
#' @export
fun_clu <- function(data, k, trans = log10, inv.cov = NULL,
                    initial.pars = NULL, iter.max = 1e2){
  #attribute
  data = as.matrix(data)
  n = dim(data)[1]; d = dim(data)[2]; times = as.numeric(trans(colSums(data)+1));
  X = trans(data+1); eplison = 1; iter = 0;
  # initial pars
  if (is.null(initial.pars)) {
    initial.pars = get_par_int(X, k, times)
  }
  par.int <- c(initial.pars$initial_cov_params, initial.pars$initial_mu_params)
  prob_log <- log(initial.pars$initial_probibality)
  
  while( abs(eplison) > 1e-3 && iter <= iter.max ){
    #E step
    par.mu <- matrix(par.int[-c(1:2)],nrow = k,ncol = 2 )
    par.cov = par.int[1:2]
    cov = get_SAD1_covmatrix(par.cov[1:2], n = d)
    mu <- power_equation(times, par.mu[1:k,])
    
    mvn_log <- sapply(1:k, function(c) dmvnorm(X, mu[c,], cov, log = T))
    
    mvn = sweep(mvn_log, 2, FUN = '+', STATS =  prob_log )
    
    omega_log = t(sapply(1:n, function(c) mvn[c,] - logsumexp(mvn[c,]) ))
    omega = exp(omega_log)
    
    LL.mem <- Q_function(par = par.int, prob_log = prob_log, omega_log, X, k, times)
    
    #M step
    prob_exp = apply(omega_log, 2, logsumexp)
    prob_log = prob_exp - log(n)
    
    Q.maximization <- try(optim(par = par.int, Q_function,
                                prob_log = prob_log,
                                omega_log = omega_log,
                                X = X,
                                k = k,
                                times = times,
                                method = "BFGS",
                                control = list(trace = TRUE,maxit = 1e2
                                )))
    if ('try-error' %in% class(Q.maximization))
      break
    par.hat <- Q.maximization$par
    par.int = par.hat
    LL.next <- Q_function(par = par.hat, prob_log = prob_log, omega_log, X, k, times)
    eplison <-  LL.next - LL.mem
    LL.mem <- LL.next
    iter = iter + 1
    
    cat("\n", "iter =", iter, "\n", "Log-Likelihood = ", LL.next, "\n")
  }
  AIC = 2*(LL.next) + 2*(length(par.hat)+k-1)
  BIC = 2*(LL.next) + log(n)*(length(par.hat)+k-1)
  
  omega = exp(omega_log)
  X.clustered <- data.frame(X, apply(omega,1,which.max))
  
  return_obj <- list(cluster_number = k,
                     Log_likelihodd = LL.mem,
                     AIC = AIC,
                     BIC = BIC,
                     cov_par = par.cov,
                     mu_par = par.mu,
                     probibality = exp(prob_log),
                     omega = omega,
                     cluster = X.clustered,
                     cluster2 = data.frame(data, apply(omega,1,which.max)),
                     Time = times,
                     original_data = data)
  return(return_obj)
}


#' @title parallel version for functional clustering
#' @import parallel
#' @param data data for cluster
#' @param start vector for the minimum cluster number
#' @param end vector for the maximum cluster number
#' @return the initial parameters for functional clustering
#' @export
fun_clu_parallel <- function(data, start, end){
  core.number <- detectCores()
  cl <- makeCluster(getOption("cl.cores", core.number))
  clusterEvalQ(cl, {library(mvtnorm)})
  clusterExport(cl,c("fun_clu","get_par_int","Q_function","logsumexp","power_equation_base",
                     "power_equation_all","power_equation","get_SAD1_covmatrix","data"),
                envir=environment())
  result <- parLapply(cl=cl, start:end, function(c) fun_clu(data = data, k = c))
  stopCluster(cl)

  return(result)
}



#' @title plot BIC results for functional clustering
#' @param result list directly from fun_clu_parallel function
#' @import ggplot2
#' @return the BIC plot
#' @export
fun_clu_BIC <- function(result){
  options(warn=-1)
  BIC.df = data.frame( k = sapply( result , "[[" , 'cluster_number' ),
                       BIC = sapply( result , "[[" , 'BIC' ) )
  min.k = BIC.df$k[which.min(BIC.df$BIC)]
  p = ggplot(BIC.df)+ theme_bw() + geom_line(aes(x = BIC.df$k ,y = BIC.df$BIC), color = 'grey10') +
    geom_vline(xintercept = min.k, linetype="dashed", color = "red", size=1.5) +
    xlab("K") + ylab("BIC")
  return(p)
}


#' @title convert result of functional clustering result
#' @param result list directly from fun_clu_parallel function
#' @param best.k scale of BIC-determined cluster number
#' @return list contain module data and fitted data
#' @export
fun_clu_convert <- function(result, best.k){
  cluster.result = result[[which(sapply( result , "[[" , 'cluster_number' )==best.k)]]
  
  times = cluster.result$Time
  times_new = seq(min(times),max(times),length = 30)
  
  par.mu = cluster.result$mu_par
  colnames(par.mu) = c("a","b")
  rownames(par.mu) = paste0("M",1:best.k)
  
  k = cluster.result$cluster_number
  mu.fit = power_equation(times_new, par.mu[1:k,])
  colnames(mu.fit) = times_new
  rownames(mu.fit) = paste0("M",1:best.k)
  
  df = cluster.result$cluster2
  tmp = split(df,df$apply.omega..1..which.max.)
  tmp2 = lapply(tmp, function(x) { x["apply.omega..1..which.max."] <- NULL; x })
  
  return_obj <- list(original_data = mu.fit,
                     trans_data = mu.fit,
                     power_par = par.mu,
                     power_fit = mu.fit,
                     Module.all = tmp2)
  return(return_obj )
}

#' @title parallel version for functional clustering
#' @param result list directly from fun_clu_parallel function
#' @param best.k scale of BIC-determined cluster number
#' @param label relabel x and y label due to log-transform, set 10 as default
#' @import ggplot2
#' @importFrom reshape2 melt
#' @import scales
#' @return functional clustering plot
#' @export
fun_clu_plot <- function(result, best.k, label = math_format(expr = 10^.x)){
  options(warn=-1)
  cluster.result = result[[which(sapply( result , "[[" , 'cluster_number' )==best.k)]]

  times = cluster.result$Time
  times_new = seq(min(times),max(times),length = 30)

  par.mu = cluster.result$mu_par
  k = cluster.result$cluster_number
  alpha = table(cluster.result$cluster$apply.omega..1..which.max.)

  mu.fit = power_equation(times_new, par.mu[1:k,])
  colnames(mu.fit) = times_new
  mu.fit = melt(as.matrix(mu.fit))
  colnames(mu.fit) = c("cluster","x","y")
  mu.fit$x = as.numeric(as.character(mu.fit$x))

  plot.df = cluster.result$cluster
  X = plot.df[,-ncol(plot.df)]
  plot.df$name = rownames(plot.df)
  colnames(plot.df) = c(times,"cluster","name")

  plot.df = melt(plot.df, id.vars = c('cluster',"name"))
  colnames(plot.df) = c("cluster","name", "x","y")
  plot.df$x = as.numeric(as.character(plot.df$x))

  plot.df$alpha = NA
  for (i in 1:best.k) {
    plot.df[which(plot.df$cluster==i),]$alpha = 3/alpha[i]
  }

  name.df = data.frame(label = paste0("M",1:best.k,"(",alpha ,")"),
                       x = mean(range(times)), y = max(X)*0.9, cluster = 1:best.k)


  p = ggplot() + geom_line(plot.df,
                           mapping = aes(x = plot.df$x, y = plot.df$y,
                                         colour = factor(plot.df$cluster),
                                         group = plot.df$name),
                           alpha = plot.df$alpha, show.legend = F) +
    geom_line(mu.fit, mapping = aes(x = mu.fit$x, y = mu.fit$y, colour = factor(mu.fit$cluster)),
              size=1.25, show.legend = F)+
    facet_wrap(~cluster) +
    xlab("Habitat Index") + ylab("Microbial Abundance") + theme(axis.title=element_text(size=18)) +
    scale_x_continuous(labels = label) + scale_y_continuous(labels = label) +
    geom_text(name.df, mapping = aes(x = name.df$x, y = name.df$y,label = name.df$label),
              check_overlap = TRUE, size = 4) +
    theme_bw() +
    theme(axis.title=element_text(size=15),
          axis.text.x = element_text(size=10),
          axis.text.y = element_text(size=10,hjust = 0),
          panel.spacing = unit(0.0, "lines"),
          plot.margin = unit(c(1,1,1,1), "lines"),
          strip.background = element_blank(),
          plot.background = element_blank(),
          strip.text = element_blank())
  return(p)
}
