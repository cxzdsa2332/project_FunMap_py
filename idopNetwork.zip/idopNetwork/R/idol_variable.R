#'only used for math_format and ggplot2
#'@name GB
globalVariables(c(".x","x","y","Var1","Var2","value","variable"))
